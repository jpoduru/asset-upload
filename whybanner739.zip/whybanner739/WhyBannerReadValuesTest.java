package com.ehi.dam.reboot.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.lenient;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import junitx.util.PrivateAccessor;

/**
 *
 * @author X264517
 *
 * @category Junit test class for WhyBannerReadValuesTest class
 *
 */
@ExtendWith({ MockitoExtension.class })
public class WhyBannerReadValuesTest {

	@InjectMocks
	WhyBannerReadValues whyBannerReadValues;
	
	@Mock
	Resource resource;

	@BeforeEach
	void init() throws NoSuchFieldException {
		PrivateAccessor.setField(whyBannerReadValues, "whyBannerTitle", "whyBannerTitle");
		PrivateAccessor.setField(whyBannerReadValues, "whyBannerDesc", "whyBannerDesc");
		PrivateAccessor.setField(whyBannerReadValues, "whyBannerRadius", "whyBannerRadius");
		PrivateAccessor.setField(whyBannerReadValues, "whyBannerTheme", "whyBannerTheme");
		PrivateAccessor.setField(whyBannerReadValues, "whyBannerDisclaimerText", "whyBannerDisclaimerText");
		PrivateAccessor.setField(whyBannerReadValues, "resource", resource);
		lenient().when(resource.getName()).thenReturn("whyBannerObjects");
	}

	@Test
	void test() {
		assertEquals("whyBannerTitle", whyBannerReadValues.getWhyBannerTitle());
		assertEquals("whyBannerDesc", whyBannerReadValues.getWhyBannerDesc());
		assertEquals("whyBannerRadius", whyBannerReadValues.getWhyBannerRadius());
		assertEquals("whyBannerTheme", whyBannerReadValues.getWhyBannerTheme());
		assertEquals("whyBannerDisclaimerText", whyBannerReadValues.getWhyBannerDisclaimerText());
	}

}
