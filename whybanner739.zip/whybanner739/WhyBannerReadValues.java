package com.ehi.dam.reboot.core.models;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
/**
*
* @author X264517
*
* @category Java class for WhyBannerReadValues
*
*/

@Model(adaptables = {Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class WhyBannerReadValues {
	
	/** fetching WhyBannerTitle field from the dialog*/
    @ValueMapValue
    private String whyBannerTitle;
    
    /** fetching WhyBannerDesc field from the dialog*/
    @ValueMapValue
    private String whyBannerDesc;
    
	/** fetching WhyBannerRadius field from the dialog*/
    @ValueMapValue
    private String whyBannerRadius;
    
    /** fetching WhyBannerObjects field from the dialog*/
    @Inject
    private Resource whyBannerObjects;
    
    /** fetching WhyBannerTheme field from the dialog*/
    @ValueMapValue
    private String whyBannerTheme;
    
    /** fetching WhyBannerDisclaimerText  field from the dialog*/
    @ValueMapValue
    private String whyBannerDisclaimerText ;
    
    public String getWhyBannerTitle() {
		return whyBannerTitle;
	}

	public String getWhyBannerDesc() {
		return whyBannerDesc;
	}

	public String getWhyBannerRadius() {
		return whyBannerRadius;
	}

	public Resource getWhyBannerObjects() {
		return whyBannerObjects;
	}

	public String getWhyBannerTheme() {
		return whyBannerTheme;
	}

	public String getWhyBannerDisclaimerText() {
		return whyBannerDisclaimerText;
	}
}
